import instance from "./Axios";
import axios from "./Axios";

export const login = (loginid) => {
  return instance.post("/login", loginid);
}
export const product = (productid) => {
  return axios.post("/dashboard/all_data_count", productid);
}
