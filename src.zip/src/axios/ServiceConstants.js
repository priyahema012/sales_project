export const BASE_URL = " //cbe.themaestro.in:8021/sales_mguru_api/";
