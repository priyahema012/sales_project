// ../reducers/AuthReducer.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  productList: [],
  token: ''
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    handleLogin: (state, action) => {
      state.token = action.payload;
    },
    handleProductList: (state, action) => {
      state.productList = action.payload;
    }
  }
});

export const { handleLogin, handleProductList } = authSlice.actions;
export default authSlice.reducer;
