// ../redux/configs/Store.js
import { configureStore } from "@reduxjs/toolkit";
import rootReducers from '../configs/RootReducer'; // Ensure the path is correct

export const store = configureStore({ reducer: rootReducers });
