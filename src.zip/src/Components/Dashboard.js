import React, { useEffect, useState } from "react";
import { product } from "../axios/Services";
import { useDispatch, useSelector } from "react-redux";
import { handleLogin } from "../redux/reducers/AuthReducer";
import './Dashboard.css';


function Dashboard() {
  const selector = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const [inputs, setInput] = useState("");
  const [data, SetData] = useState([]);
   
  const handlegetData = () => {
   
    let formdata = new FormData();
    formdata.append("token", selector.token);
    setInput(selector.token);

    product(formdata)
      .then((res) => {
        console.log("API Response:", res.data);
       
        if (res.data && Array.isArray(res.data.data)) {
          SetData(res.data.data);
        } else if (Array.isArray(res.data)) {
          SetData(res.data);
        } else {
          console.error("Unexpected data structure:", res.data);
        }
      })
      .catch((err) => {
        console.log("API Error:", err);
      });
  };

  useEffect(() => {
    if (selector.token) {
      handlegetData();
    }
  }, [selector.token]); 

  useEffect(() => {
    console.log("Current Data:", data);
  }, [data]);

  return (
    <>
      <div className="row">
        {Array.isArray(data) && data.length > 0 ? (
          data.map((item, index) => (
            <div className="col" key={index}>
              <div className="card">
  <p className="card-title">{item.displayName}</p>
  <p className="card-leads-title">{item.leads.displayName}</p>
  <p className="card-leads-value">{item.leads.value}</p>
  <p className="card-overdue-title">{item.over_due.displayName}</p>
  <p className="card-overdue-value">{item.over_due.value}</p>
</div>

            </div>
          ))
        ) : (
          <p>No data available</p>
        )}
      </div>
    </>
  );
}

export default Dashboard;
