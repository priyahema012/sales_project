import React from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import classes from "../Components/Login.module.css";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import logo from "../assets/brand_logo1.png";
import logo1 from "../assets/20230513-638195543589661123-3202-3.png";
import logo2 from "../assets/logo2.png";
import logo3 from "../assets/logo3.png";
import { login } from "../axios/Services";
import sha1 from "sha1";
import { useNavigate } from "react-router-dom";
import { handleLogin } from "../redux/reducers/AuthReducer";
import { useDispatch } from "react-redux";

const validationSchema = Yup.object({
  userName: Yup.string().required("Username is required"),
  password: Yup.string().required("Password is required"),
});

export default function Login() {
  const dispatch=useDispatch();
  const navigate = useNavigate();
  const { values, handleChange, handleBlur, touched, errors, handleSubmit } =
    useFormik({
      initialValues: {
        userName: "",
        password: "",
      },
      validationSchema: validationSchema,
      onSubmit: (values) => {
        const formData = new FormData();
        formData.append("userName", values.userName);
        formData.append("password", values.password);
        formData.append("device_type", "3");
        formData.append(
          "authcode",
          sha1("lkjfjIHJL@fdj385!jhg" + values.userName)
        );

        login(formData)
          .then((response) => {
            localStorage.setItem("userdata",JSON.stringify(response.data))
            dispatch(handleLogin(response.data.token))
            console.log("Login successful:", response.data);
            // Navigate to dashboard after successful login
            navigate("/dash");
          })
          .catch((error) => {
            console.error("Login error:", error);
          });
      },
    });

  return (
    <div className={`container ${classes.container}`}>
      <div className="row">
        <div className={`col-md-6 ${classes.loginLeft}`}>
          <div className={classes.loginBox}>
            <div className={`mb-4 ${classes.logo}`}>
              <img src={logo} alt="Logo" height={"50px"} />
            </div>
            <h3 className={classes.textOrange}>Hello!</h3>
            <p>Sign in to your account to continue</p>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Username"
                  name="userName"
                  value={values.userName}
                  onChange={handleChange}
                   onBlur={handleBlur}
                />
                {touched.userName && errors.userName ? (
                  <div className="text-danger">{errors.userName}</div>
                ) : null}
                <i className={` ${classes.icon}`}></i>
              </div>
              <div className="mb-3">
                <input
                  type="password"
                  className="form-control"
                  placeholder="Password"
                  name="password"
                  value={values.password}
                  onChange={handleChange}
                  onBlur={handleBlur}
                />
                {touched.password && errors.password ? (
                  <div className="text-danger">{errors.password}</div>
                ) : null}
                <i className={` ${classes.icon}`}></i>
              </div>
              <button type="submit" className={`w-50 ${classes.btn}`}>
                LOG IN
              </button>
            </form>
          </div>
        </div>

        <div className={`col-md-6`}>
          <div
            id="carouselExampleAutoplaying"
            className="carousel slide"
            data-bs-ride="carousel"
          >
            <div className="carousel-inner">
              <div className="carousel-item active">
                <img src={logo1} className="d-block w-100" alt="..." />
              </div>
              <div className="carousel-item">
                <img src={logo2} className="d-block w-100" alt="..." />
              </div>
              <div className="carousel-item">
                <img src={logo3} className="d-block w-100" alt="..." />
              </div>
            </div>
            <button
              className="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleAutoplaying"
              data-bs-slide="prev"
            >
              <span
                className="carousel-control-prev-icon"
                aria-hidden="true"
              ></span>
              <span className="visually-hidden">Previous</span>
            </button>
            <button
              className="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleAutoplaying"
              data-bs-slide="next"
            >
              <span
                className="carousel-control-next-icon"
                aria-hidden="true"
              ></span>
              <span className="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
