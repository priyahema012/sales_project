import React from 'react';
import { createBrowserRouter, RouterProvider, Outlet } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

import Login from "./Components/Login";
import Navpage from "./Components/Navpage";  // Use the imported Navpage component
import Dashboard from './Components/Dashboard';
import { AuthPrivateRouter, HomePrivateRouter } from './Components/PrivateRouter';

function App() {
  const router = createBrowserRouter([
    {
      path: "/login",
      element: <AuthPrivateRouter />,
      children: [
        {
          path: "",
          element: <Login />,
        },
      ],
    },
    {
      path: "/",
      element: <HomePrivateRouter />,
      children: [
        {
          path: "/",
          element: <Navpage />,  // Reference the Navpage component here
          children: [
            {
              path: "dash",
              element: <Dashboard />,
            },
            

          ],
        },
      ],
    },
  ]);

  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
